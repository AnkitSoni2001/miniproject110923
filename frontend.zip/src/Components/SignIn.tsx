import Cookies from "js-cookie";
import React from "react";
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../Styles/SignIn.css";

import Image from "../Images/logo.png"

const SignIn: React.FC = () => {
    var Navigate = useNavigate();
    const [email, setEmail] = useState<string>("");
    const [password, setPassword] = useState<string>("");


    const Info = {
        email: email,
        password: password,
    };

    const handleSignIn = async () => {
        if (email && password) {
            try {
                const response = await axios.post("http://localhost:8000/signin", Info);
                const responseData = response.data; 
                console.log(responseData);
                
                if (responseData.message === "Login Successfully") {
                    alert("You have successfully logged in!");
                    Cookies.set("userInfo", email);
                    Navigate("/home");
                }

                if (responseData.message === "Password Incorrect") {
                    alert("Invalid credentials");
                }

                if (responseData.message === "User does not exist") {
                    alert("User does not exist");
                }

                // if (responseData.message === "All fields are required") {
                //     alert("All fields are required");
                // }

            } catch (error) {
                console.error("Error signing in:", error);
            }

        } else {
            alert("All fields are required!");
        }

    };

    return (
        <>
            <div className="signInContainer">
                <div className="signin_head">
                    <img src={Image} className="logo" alt="Logo" />
                    <h2 className="signin_h2">Jin</h2>                   
                </div>

                <form className="signInForm">
                    <div className="email">
                        <label className="lable">Email:</label>
                        <input className="input"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div className="password">
                        <label className="lable">Password:</label>
                        <input className="input"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    <div>
                        <button type="button" className="signin_btn" onClick={handleSignIn}>
                            Sign In
                        </button>
                    </div>

                    <div className="signin_footer">
                        <p className="signin_p_tag">Not Registered? <a href="/signup">Sign Up</a></p>          
                    </div>
                    
                </form>
            </div>
        </>
    );
};

export default SignIn;
